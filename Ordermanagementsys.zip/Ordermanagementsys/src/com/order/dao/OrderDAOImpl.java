package com.order.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.order.entity.Orders;
import com.order.entity.Product;
import com.order.entity.User;
import com.order.exception.OrderNotFoundException;
import com.order.exception.UserNotFoundException;
import com.order.util.DBUtil;

public class OrderDAOImpl implements IOrderDAO {
	
	private static Connection connOrder;

	@Override
	public int createOrder(Orders order) throws ClassNotFoundException, SQLException ,OrderNotFoundException{
		connOrder = DBUtil.createConnection();
		String query="INSERT INTO orders(userid,productid,orderdate,quantity,total) "
				+ "VALUES(?,?,?,?,?)";
		Date orderdate = Date.valueOf(order.getOrderdate());
		
		PreparedStatement preparest=connOrder.prepareStatement(query);
		preparest.setInt(1, order.getUser().getUserid());
		preparest.setInt(2, order.getProduct().getProductid());
		preparest.setDate(3, orderdate);
		preparest.setInt(4, order.getQuantity());
		preparest.setInt(5, order.getTotal());
		int result=preparest.executeUpdate();
		DBUtil.closeConnection();
		return result;
	}

	@Override
	public int cancelOrder(int orderid) throws ClassNotFoundException, SQLException ,OrderNotFoundException{
		Orders order = null;
		Product product=null;
		User user=null;
		 
		int userid = 0;
		int productid = 0;
		Date orderdate = null;
		int quantity = 0;
		int total=0;
 
		int result = 0;
		
		connOrder = DBUtil.createConnection();
 
		String queryCheck = "SELECT * FROM orders WHERE orderId = ?";
		String queryDelete = "DELETE FROM orders WHERE orderId = ?";

		PreparedStatement prepareSt = connOrder.prepareStatement(queryCheck);
		PreparedStatement prepareCustomerDelete = connOrder.prepareStatement(queryDelete);
		
		prepareSt.setInt(1, orderid);
		prepareCustomerDelete.setInt(1, orderid);
		
		ResultSet rs = prepareSt.executeQuery();
 
		while (rs.next()) {// Till there are further records.
			userid = rs.getInt("userId");
			productid = rs.getInt("productId");
			orderdate=rs.getDate("orderDate");
			quantity = rs.getInt("quantity");
			total = rs.getInt("total");
 
			order = new Orders();
			order.setOrderid(orderid);
		}
 
		if (order == null) {
			throw new OrderNotFoundException("No Customer Found");
		}else {
			result = prepareCustomerDelete.executeUpdate();
		}
 
		DBUtil.closeConnection();
		
		return result;

	}

	@Override
	public int createProduct(Product product) throws ClassNotFoundException, SQLException {
		connOrder = DBUtil.createConnection();
		String query="INSERT INTO products(productname,productdescription,productprice,quantityinstock,type) "
				+ "VALUES(?,?,?,?,?)";
		
		PreparedStatement preparest=connOrder.prepareStatement(query);
		preparest.setString(1, product.getProductname());
		preparest.setString(2, product.getDescription());
		preparest.setDouble(3, product.getPrice());
		preparest.setInt(4, product.getQuantityInStock());
		preparest.setString(5, product.getType());
		int result=preparest.executeUpdate();
		DBUtil.closeConnection();
		return result;
	}

	@Override
	public int CreateUser(User user) throws ClassNotFoundException, SQLException ,UserNotFoundException{
		connOrder = DBUtil.createConnection();
		String query="INSERT INTO users(username,password,role) "
				+ "VALUES(?,?,?)";
		
		PreparedStatement preparest=connOrder.prepareStatement(query);
		preparest.setString(1, user.getUsername());
		preparest.setString(2, user.getPassword());
		preparest.setString(3, user.getRole());
		int result=preparest.executeUpdate();
		DBUtil.closeConnection();
		return result;
	}

	@Override
	public List<Product> viewProducts() throws ClassNotFoundException, SQLException {
		List<Product>prolist=new ArrayList<>();
		Product product=null;
		
		int productid=0;
		String productname=null;
		String description=null;
		double price=0;
		int quantitystock=0;
		String type=null;
		
		connOrder = DBUtil.createConnection();
		String query="SELECT * FROM products";
		
		PreparedStatement preparest=connOrder.prepareStatement(query);
		ResultSet rs=preparest.executeQuery();
		
		while(rs.next()) {
			productid=rs.getInt("productId");
			productname=rs.getString("productName");
			description=rs.getString("productDescription");
			price=rs.getDouble("productPrice");
			quantitystock=rs.getInt("quantityinstock");
			type=rs.getString("type");
			
			product = new Product(productname,description,price,quantitystock,type);
			product.setProductid(productid);
			prolist.add(product);
			
		}
		DBUtil.closeConnection();
		return prolist;
	}

	@Override
	public Orders viewOrder(int userid) throws ClassNotFoundException, SQLException ,OrderNotFoundException{
		Orders order=null;
		User user=null;
		int userId=0;
		String username;
		String password;
		String role;
		int orderid=0;
		LocalDate orderdate=null;
		int quantity=0;
		int total=0;
		
		connOrder = DBUtil.createConnection();
		String query="SELECT o.orderId,o.userId,u.username,u.password,u.role,o.orderDate,o.quantity,o.total "
				+ "FROM User u JOIN Orders o "
				+ "ON u.userId=o.userId "
				+ "WHERE userId = ?";
		
		PreparedStatement preparest=connOrder.prepareStatement(query);
		preparest.setInt(1, userid);
		ResultSet rs=preparest.executeQuery();
		
		while(rs.next()) {
			userId=rs.getInt("userId");
			username=rs.getString("username");
			password=rs.getString("password");
			role=rs.getString("role");
			orderdate = rs.getDate("orderDate").toLocalDate();
			orderid=rs.getInt("orderId");
			quantity=rs.getInt("quantity");
			total=rs.getInt("total");
			
			user = new User(username, password, role);
			user.setUserid(userId);
			
			order = new Orders(orderid, orderdate, quantity, total, user);		
		}
		DBUtil.closeConnection();
		if(order==null) {
			throw new OrderNotFoundException("customer not found");
		}
		return order;

	}

}
