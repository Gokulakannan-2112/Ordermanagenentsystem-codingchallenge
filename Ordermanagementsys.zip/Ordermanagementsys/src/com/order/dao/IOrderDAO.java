package com.order.dao;

import java.sql.SQLException;
import java.util.List;

import com.order.entity.Orders;
import com.order.entity.Product;
import com.order.entity.User;
import com.order.exception.OrderNotFoundException;
import com.order.exception.UserNotFoundException;

public interface IOrderDAO {
	public int createOrder(Orders order)throws ClassNotFoundException,SQLException,OrderNotFoundException;
	public int cancelOrder(int orderid)throws ClassNotFoundException,SQLException,OrderNotFoundException;
	public int createProduct(Product product)throws ClassNotFoundException,SQLException;
	public int CreateUser(User user)throws ClassNotFoundException,SQLException,UserNotFoundException;
	public List<Product>viewProducts()throws ClassNotFoundException,SQLException;
	public Orders viewOrder(int userid)throws ClassNotFoundException,SQLException,OrderNotFoundException;

}
