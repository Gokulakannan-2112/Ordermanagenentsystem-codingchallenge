package com.order.service;

import java.util.List;

import com.order.entity.Orders;
import com.order.entity.Product;
import com.order.entity.User;

public interface IOrderService {
	public int createOrder(Orders order);
	public int cancelOrder(int orderid);
	public int createProduct(Product product);
	public int CreateUser(User user);
	public List<Product>viewProducts();
	public Orders viewOrder(int userid);

}
