package com.order.service;

import java.sql.SQLException;
import java.util.List;

import com.order.dao.IOrderDAO;
import com.order.dao.OrderDAOImpl;
import com.order.entity.Orders;
import com.order.entity.Product;
import com.order.entity.User;
import com.order.exception.OrderNotFoundException;
import com.order.exception.UserNotFoundException;

public class OrderServiceImpl implements IOrderService {
	private IOrderDAO iorderDAO;
	

	public OrderServiceImpl() {
		super();
		iorderDAO = new OrderDAOImpl();
	}
	

	@Override
	public int createOrder(Orders order) {
		int result=0;
		try {
			result=iorderDAO.createOrder(order);
		}catch(ClassNotFoundException cnfe) {
			System.out.println("looks like driver not found");
		}catch(SQLException se) {
			System.out.println("either url,username or password are wrong");
		}catch(OrderNotFoundException one) {
			System.out.println(one.getMessage());
		}
		return result;
	}

	@Override
	public int cancelOrder(int orderid) {
		int result=0;
		try {
		result=iorderDAO.cancelOrder(orderid);
		}catch(ClassNotFoundException cnfe) {
			System.out.println("looks like driver not found");
		}catch(SQLException se) {
			System.out.println("either url,username or password are wrong");
		}catch(OrderNotFoundException cfe) {
			System.out.println(cfe.getMessage());
		}		
		return result;
	}

	@Override
	public int createProduct(Product product) {
		int result=0;
		try {
			result=iorderDAO.createProduct(product);
		}catch(ClassNotFoundException cnfe) {
			System.out.println("looks like driver not found");
		}catch(SQLException se) {
			System.out.println("either url,username or password are wrong");
		}
		return result;
	}

	@Override
	public int CreateUser(User user) {
		int result=0;
		try {
			result=iorderDAO.CreateUser(user);
		}catch(ClassNotFoundException cnfe) {
			System.out.println("looks like driver not found");
		}catch(SQLException se) {
			System.out.println("either url,username or password are wrong");
		}catch(UserNotFoundException une) {
			System.out.println(une.getMessage());
		}
		return result;
	}

	@Override
	public List<Product> viewProducts() {
		List<Product>productlist=null;
		try {
		productlist=iorderDAO.viewProducts();
		}catch(ClassNotFoundException cnfe) {
			System.out.println("looks like driver not found");
		}catch(SQLException se) {
			System.out.println("either url,username or password are wrong");
		}
		return productlist;

	}

	@Override
	public Orders viewOrder(int userid) {
		Orders order=null;
		try {
		order=iorderDAO.viewOrder(userid);
		}catch(ClassNotFoundException cnfe) {
			System.out.println("looks like driver not found");
		}catch(SQLException se) {
			System.out.println("either url,username or password are wrong");
		}catch(OrderNotFoundException cfe) {
			System.out.println(cfe.getMessage());
		}		
		return order;
	}

}
