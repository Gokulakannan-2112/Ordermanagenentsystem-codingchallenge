package com.order.entity;

public class Clothing extends Product {
	private int size;
	private String color;
	private String material;
	private Product product;
	
	public Clothing() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Clothing(int size, String color, String material, Product product) {
		super();
		this.size = size;
		this.color = color;
		this.material = material;
		this.product = product;
	}

	public int getSize() {
		return size;
	}

	public void setSize(int size) {
		this.size = size;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public String getMaterial() {
		return material;
	}

	public void setMaterial(String material) {
		this.material = material;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	
}
