package com.order.entity;

public class Electronics extends Product {
	private String brand;
	private int warranty;
	private Product product;

	public Electronics() {
		super();
	}

	public Electronics(String brand, int warranty, Product product) {
		super();
		this.brand = brand;
		this.warranty = warranty;
		this.product = product;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public int getWarranty() {
		return warranty;
	}

	public void setWarranty(int warranty) {
		this.warranty = warranty;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}
	

}
