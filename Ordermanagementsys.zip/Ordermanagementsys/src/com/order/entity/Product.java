package com.order.entity;

public class Product {
	private int productid;
	private String productname;
	private String description;
	private double price;
	private int quantityInStock;
	private String type;
	
	public Product() {
		super();
	}
	
	public Product(int productid, String productname, String description, double price, int quantityInStock,
			String type) {
		super();
		this.productid = productid;
		this.productname = productname;
		this.description = description;
		this.price = price;
		this.quantityInStock = quantityInStock;
		this.type = type;
	}
	
	public Product(String productname, String description, double price, int quantityInStock, String type) {
		super();
		this.productname = productname;
		this.description = description;
		this.price = price;
		this.quantityInStock = quantityInStock;
		this.type = type;
	}

	public int getProductid() {
		return productid;
	}
	public void setProductid(int productid) {
		this.productid = productid;
	}
	public String getProductname() {
		return productname;
	}
	public void setProductname(String productname) {
		this.productname = productname;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public int getQuantityInStock() {
		return quantityInStock;
	}
	public void setQuantityInStock(int quantityInStock) {
		this.quantityInStock = quantityInStock;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	
	

}
