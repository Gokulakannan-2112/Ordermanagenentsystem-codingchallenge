package com.order.entity;

import java.time.LocalDate;

public class Orders {
	private int orderid;
	private LocalDate orderdate;
	private int quantity;
	private int total;
	private User user;
	private Product product;
	private int userid;
	private int productid;
	
	public Orders() {
		super();
	}

	public Orders(int orderid, LocalDate orderdate, int quantity, int total, User user, Product product) {
		super();
		this.orderid = orderid;
		this.orderdate = orderdate;
		this.quantity = quantity;
		this.total = total;
		this.user = user;
		this.product = product;
	}
	

	public Orders(LocalDate orderdate, int quantity, int total, int userid, int productid) {
		super();
		this.orderdate = orderdate;
		this.quantity = quantity;
		this.total = total;
		this.userid = userid;
		this.productid = productid;
	}

	public Orders(int orderid, LocalDate orderdate, int quantity, int total, User user) {
		super();
		this.orderid = orderid;
		this.orderdate = orderdate;
		this.quantity = quantity;
		this.total = total;
		this.user = user;
	}

	public int getOrderid() {
		return orderid;
	}

	public void setOrderid(int orderid) {
		this.orderid = orderid;
	}

	public LocalDate getOrderdate() {
		return orderdate;
	}

	public void setOrderdate(LocalDate orderdate) {
		this.orderdate = orderdate;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}
	

}
