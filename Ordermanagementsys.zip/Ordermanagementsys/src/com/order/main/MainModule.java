package com.order.main;

import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

import com.order.entity.Orders;
import com.order.entity.Product;
import com.order.entity.User;
import com.order.service.IOrderService;
import com.order.service.OrderServiceImpl;

public class MainModule {

	public static void main(String[] args) {
		IOrderService orderservice = new OrderServiceImpl();
		User user=null;
		Orders order=null;
		Product product=null;
		int userid=0;
		int productid=0;
		String productname=null;
		String description=null;
		double price=0;
		int quantitystock=0;
		String type=null; 
		LocalDate orderdate=null;
		String username=null;
		String password=null;
		String role=null;
		
		int year = 0 ;
		int month = 0 ;
		int dayOfMonth = 0;
		int quantity=0;
		int total=0;
		int choice = -1;
		int success=0;
		Scanner sc = new Scanner(System.in);

				while (choice != 0) {
					System.out.println("Following are the options:");
					System.out.println("1. Create User");
					System.out.println("2. Cancel Order");
					System.out.println("3. Create Order");
					System.out.println("6. Create Product");
					System.out.println("4. get all products");
					System.out.println("5. get order by user");
					System.out.println("0. Exit");
					System.out.print("Please enter your choice: ");

					choice = sc.nextInt();
					sc.nextLine();

					switch (choice) {
					case 1:
						System.out.print("Enter firstname:");
						username = sc.nextLine();

						System.out.print("Enter password:");
						password = sc.nextLine();

						System.out.print("Enter role:");
						role = sc.nextLine();


						user = new User(username, password, role);
						success = orderservice.CreateUser(user);

						if (success == 1) {
							System.out.println("record inserted successfully...");
						}

						break;
					case 2:
						System.out.println("You have chosen updation of vehicle.");
						break;
					case 3:
						System.out.print("Enter userid:");
						userid = sc.nextInt();
						sc.nextLine();

						System.out.print("Enter productid:");
						productid = sc.nextInt();
						sc.nextLine();

						System.out.println("Enter order Date: ");
						System.out.print("Enter year: ");
						year = Integer.parseInt(sc.nextLine());
						
						System.out.print("Enter month: ");
						month = Integer.parseInt(sc.nextLine());
						
						System.out.print("Enter day of month: ");
						dayOfMonth = Integer.parseInt(sc.nextLine());
						
						orderdate = LocalDate.of(year, month, dayOfMonth);
						
						System.out.print("Enter quantity:");
						quantity = sc.nextInt();

						System.out.print("Enter total:");
						total = sc.nextInt();
						user = new User();
						user.setUserid(userid);
						
						product = new Product();
						product.setProductid(productid);
						
						order = new Orders(orderdate,quantity,total,userid,productid);
						success = orderservice.createOrder(order);

						if (success == 1) {
							System.out.println("record inserted successfully...");
						}

						break;
					case 4:
						List<Product>productlist=orderservice.viewProducts();
						System.out.println("following are the products:");
						for (Product products : productlist) {
							System.out.println(products);
						}
						break;
					case 5:
						System.out.println("enter userid:");
						userid=sc.nextInt();
						sc.nextLine();
						order=orderservice.viewOrder(userid);
						if(order==null) {
							System.out.println("no such order");
						}else {
							System.out.println("the given order:");
							System.out.println(order);
						}
						break;
					case 6:
						System.out.print("Enter productname:");
						productname = sc.nextLine();

						System.out.print("Enter description:");
						description = sc.nextLine();

						System.out.print("Enter price:");
						price = sc.nextInt();
						sc.nextLine();
						
						System.out.print("Enter quantityinstock:");
						quantitystock = sc.nextInt();
						sc.nextLine();

						System.out.print("Enter type:");
						type = sc.nextLine();

						product = new Product(productname, description,price,quantitystock,type);
						success = orderservice.createProduct(product);

						if (success == 1) {
							System.out.println("record inserted successfully...");
						}

						break;

					case 0:
						System.out.println("You have chosen to exit.");
						break;
					default:
						System.out.println("Incorrect option");
						break;
					}
				}
				sc.close();


			}}
